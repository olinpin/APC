import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.function.Function;

/* I honestly don't understand the current problem.
   But I guess, this is what is asked for...
 */

public class Ponger {
    private final Scanner s = new Scanner(System.in);
    private final double alpha = s.nextDouble();
    private final DecimalFormat dm = new DecimalFormat("#0.0000000");

    // Testing java 8 lambdas, because we have to test it
    private final Function<Double, Double> f = (x) -> {
        return 10 * Math.tan(Math.toRadians(x));
    };

    public static void main(String[] args) {
        (new Ponger()).solve();
    }

    void solve() {
        System.out.println(dm.format(f.apply(alpha)));
    }
}
