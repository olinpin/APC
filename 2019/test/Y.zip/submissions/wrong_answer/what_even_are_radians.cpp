#include <bits/stdc++.h>
using namespace std;

int main() {
	double a;
	cin >> a;
	
	double dx = cos(a);
	double dy = sin(a);

	double yi = (10 / dx) * dy;
	printf("%.10lf\n", yi);
	return 0;
}
