#include <bits/stdc++.h>
using namespace std;

int main() {
	double a;
	cin >> a;
	
	double dx = cos(2.0 * acos(-1) * a / 360.0);
	double dy = sin(2.0 * acos(-1) * a / 360.0);

	double yi = (10 / dx) * dy;
	printf("%.3lf\n", yi);
	return 0;
}
