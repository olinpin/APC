#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, m;
	cin >> n >> m;
	vector<int> ans(m, 0);
	iota(ans.begin(), ans.end(), 1);
	random_shuffle(ans.begin(), ans.end());
	cout << m/2 << endl;
	for (int i = 0; i < m/2; ++i)
		cout << ans[i] << '\n';
	cout << flush;
}
