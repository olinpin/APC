#include <iostream>
#include <vector>
#include <utility>

using namespace std;

int main() {
	int n, m;
	cin >> n >> m;
	vector<vector<pair<int,int>>> in(n), out(n);
	for( int i = 1; i <= m; ++i ) {
		int u, v;
		cin >> u >> v;
		if( u < v )
			out[u-1].emplace_back( v-1, i );
		else
			in[v-1].emplace_back( u-1, i );
	}
	vector<int> remove;
	for( int i = 0; i < n; ++i ) {
		if( out[i] > in[i] ) {
			for( auto x : in[i] )
				remove.push_back( x.second );
		} else {
			for( auto x : out[i] )
				remove.push_back( x.second );
		}
	}
	cout << remove.size() << endl;
	for( int e : remove )
		cout << e << endl;
}